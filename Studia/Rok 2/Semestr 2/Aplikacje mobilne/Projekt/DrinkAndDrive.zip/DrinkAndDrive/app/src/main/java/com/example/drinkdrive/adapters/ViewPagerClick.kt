package com.example.drinkdrive.adapters

interface ViewPagerClick {
    fun onLongClick(position: Int){
    }
}